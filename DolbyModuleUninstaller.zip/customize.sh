# space
ui_print " "

# log
if [ "$BOOTMODE" != true ]; then
  FILE=/sdcard/$MODID\_recovery.log
  ui_print "- Log will be saved at $FILE"
  exec 2>$FILE
  ui_print " "
fi

# optionals
OPTIONALS=/sdcard/optionals.prop
if [ ! -f $OPTIONALS ]; then
  touch $OPTIONALS
fi

# debug
if [ "`grep_prop debug.log $OPTIONALS`" == 1 ]; then
  ui_print "- The install log will contain detailed information"
  set -x
  ui_print " "
fi

# info
MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " ID=$MODID"
ui_print " Version=$MODVER"
ui_print " VersionCode=$MODVERCODE"
if [ "$KSU" == true ]; then
  ui_print " KSUVersion=$KSU_VER"
  ui_print " KSUVersionCode=$KSU_VER_CODE"
  ui_print " KSUKernelVersionCode=$KSU_KERNEL_VER_CODE"
else
  ui_print " MagiskVersion=$MAGISK_VER"
  ui_print " MagiskVersionCode=$MAGISK_VER_CODE"
fi
ui_print " "

# function
remove_module() {
for MODULE in $MODULES; do
  FILE=/data/adb/modules/$MODULE/uninstall.sh
  if [ -f $FILE ]; then
    sh $FILE
  fi
  FILE=/data/adb/modules_update/$MODULE/uninstall.sh
  if [ -f $FILE ]; then
    sh $FILE
  fi
  rm -rf /data/adb/modules*/$MODULE
done
}

# remove module
ui_print "- Removing Dolby modules..."
MODULES="dolbyatmos DolbyAtmos DolbyAudio
         MotoDolby DolbyAtmos360"
remove_module
MODULES=SoundEnhancement
FILE=/data/adb/modules/$MODULES/module.prop
if grep -q 'Dolby Atmos Xperia' $FILE; then
  remove_module
fi
MODULES=MiSound
FILE=/data/adb/modules/$MODULES/module.prop
if grep -q 'and Dolby Atmos' $FILE; then
  remove_module
fi
MODULES=DolbyAtmosSpatialSound
FILE=/data/adb/modules/$MODULES/module.prop
if grep -q 'Dolby Atmos and' $FILE; then
  remove_module
fi
ui_print " "

# done
ui_print "- Done"
rm -rf /data/adb/modules*/$MODID
ui_print " "
exit 0






