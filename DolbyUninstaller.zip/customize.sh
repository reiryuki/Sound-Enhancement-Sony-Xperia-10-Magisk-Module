ui_print " "

# information
MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " ID=$MODID"
ui_print " Version=$MODVER"
ui_print " VersionCode=$MODVERCODE"
ui_print " MagiskVersion=$MAGISK_VER"
ui_print " MagiskVersionCode=$MAGISK_VER_CODE"
ui_print " "

# function
remove_module() {
  for MODULES in $MODULE; do
    FILE=/data/adb/modules/$MODULES/uninstall.sh
    if [ -f $FILE ]; then
      sh $FILE
    fi
    FILE=/data/adb/modules_update/$MODULES/uninstall.sh
    if [ -f $FILE ]; then
      sh $FILE
    fi
    rm -rf /data/adb/modules*/$MODULES
  done
}

# remove module
ui_print "- Removes Dolby modules... "
MODULE="dolbyatmos"
        DolbyAudio
        MotoDolby
        DolbyAtmos"
remove_module
MODULE=SoundEnhancement
FILE=/data/adb/modules/$MODULE/module.prop
if grep -Eq 'Dolby Atmos Xperia' $FILE; then
  remove_module
fi
ui_print " "

# done
ui_print "- Done "
rm -rf /data/adb/modules*/$MODID
exit




