# space
ui_print " "

# information
MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " ID=$MODID"
ui_print " Version=$MODVER"
ui_print " VersionCode=$MODVERCODE"
ui_print " "

# mount
if [ "$BOOTMODE" != true ]; then
  if [ -e /dev/block/bootdevice/by-name/vendor ]; then
    mount -o rw -t auto /dev/block/bootdevice/by-name/vendor /vendor
  else
    mount -o rw -t auto /dev/block/bootdevice/by-name/cust /vendor
  fi
  mount -o rw -t auto /dev/block/bootdevice/by-name/product /product
  mount -o rw -t auto /dev/block/bootdevice/by-name/system_ext /system_ext
  mount -o rw -t auto /dev/block/bootdevice/by-name/odm /odm
  mount -o rw -t auto /dev/block/bootdevice/by-name/my_product /my_product
  mount -o rw -t auto /dev/block/bootdevice/by-name/persist /persist
  mount -o rw -t auto /dev/block/bootdevice/by-name/metadata /metadata
fi

# function
remove_module() {
for MODULE in $MODULES; do
  FILE=/data/adb/modules/$MODULE/uninstall.sh
  if [ -f $FILE ]; then
    sh $FILE
  fi
  FILE=/data/adb/modules_update/$MODULE/uninstall.sh
  if [ -f $FILE ]; then
    sh $FILE
  fi
  rm -rf /data/adb/modules*/$MODULE
done
}

# remove module
ui_print "- Removes Dolby modules..."
MODULES="dolbyatmos
         DolbyAudio
         MotoDolby
         DolbyAtmos"
remove_module
MODULES=SoundEnhancement
FILE=/data/adb/modules/$MODULES/module.prop
if grep -q 'Dolby Atmos Xperia' $FILE; then
  remove_module
fi
MODULES=MiSound
FILE=/data/adb/modules/$MODULES/module.prop
if grep -q 'and Dolby Atmos' $FILE; then
  remove_module
fi
ui_print " "

# done
ui_print "- Done "
ui_print " "
if [ "$BOOTMODE" != true ]; then
  ui_print "- If there is any error, copy /cache/recovery"
  ui_print "  from Recovery to /sdcard & send it"
  ui_print "  to the author."
  ui_print " "
fi
rm -rf /data/adb/modules*/$MODID
exit 0




